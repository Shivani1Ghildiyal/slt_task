package pack4;
import java.util.Scanner;


public class armstrongNo {

	    public static void main(String args[]) {

	    	        int n=0, temp = 0, r = 0, s = 0;
	    	        Scanner in = new Scanner(System.in);
	    	        System.out.println("Enter a number ");
	    	        if (in.hasNextInt()) {
	    	            n = in.nextInt(); // if there is another number  
	    	        }
	    	        temp = n;
	    	        while (n != 0) {
	    	            r = n % 10;
	    	            s = s + (r * r * r);
	    	            n = n / 10;
	    	        }

	    	        if (temp == s) {
	    	            System.out.println( " it is an Armstrong Number");
	    	        } else {
	    	            System.out.println( "it is not an Armstrong Number");
	    	        }
	    	        in.close();
	    }
}
	    	
	       